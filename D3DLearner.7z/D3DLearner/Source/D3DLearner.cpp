#include "stdafx.h"

#include "d3dUtility.h"

#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 600

IDirect3DDevice9 *Device = NULL;

bool Setup()
{
	return true;
}

bool Display(float deltaTime)
{
	if (Device)
	{
		Device->Clear(0, 0, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0x0, 1.0f, 0);
		Device->Present(0, 0, 0, 0); //present backbuffer
	}
	return true;
}

void Cleanup()
{
}

int APIENTRY _tWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPTSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	if (!d3d::InitD3D(hInstance, WINDOW_WIDTH, WINDOW_HEIGHT, false, D3DDEVTYPE_HAL, &Device))
	{
		//MessageBox(0, L"InitD3D FAILED", 0, 0);
		//return FALSE;
	}

	if (!Setup())
	{
		return FALSE;
	}

	d3d::EnterMsgLoop(Display);

	Cleanup();

	d3d::Release(Device);
	return 0;
}
